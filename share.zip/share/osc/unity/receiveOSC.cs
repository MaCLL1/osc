// code inspired in https://thomasfredericks.github.io/UnityOSC/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class receiveOSC : MonoBehaviour
{

    public OSC osc;

    // Start is called before the first frame update
    void Start()
    {
        osc.SetAddressHandler( "/move/left" , OnReceiveLeft);
        osc.SetAddressHandler( "/move/right" , OnReceiveRight);
        osc.SetAddressHandler( "/move/up" , OnReceiveUp);
        osc.SetAddressHandler( "/move/down" , OnReceiveDown);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    void OnReceiveLeft(OscMessage message) {
        float x = message.GetFloat(0);
        float y = message.GetFloat(1);

        Vector3 position = transform.position;
        
        if (position.x > -7000) {
            position.x -= 100;
        }

        transform.position = position;
    }
    
    void OnReceiveRight(OscMessage message) {
        float x = message.GetFloat(0);

        Vector3 position = transform.position;

        if (position.x < 7000) {
            position.x += 100;
        }

        transform.position = position;
    }
    
    void OnReceiveUp(OscMessage message) {
        float y = message.GetFloat(1);

        Vector3 position = transform.position;
        if (position.y < 7000) {
            position.y += 100;       
        }

        transform.position = position;
    }
    
    void OnReceiveDown(OscMessage message) {
        float y = message.GetFloat(1);

        Vector3 position = transform.position;

        if (position.y > -7000) {
            position.y -= 100;       
        }

        transform.position = position;
    }
    
    
}
